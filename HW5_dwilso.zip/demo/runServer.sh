#!/bin/bash
java --add-modules java.xml.bind -cp bin\SecureChat.jar chat.server.RunServer contexts/server.context